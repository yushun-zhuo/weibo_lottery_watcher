require('dotenv').config();
const cron = require('node-cron');
const { runMonitor } = require('../lib/monitor');

const interval = parseInt(process.env.MONITOR_INTERVAL || '5');

console.log(`Starting monitor with ${interval} minute interval...`);

runMonitor();

cron.schedule(`*/${interval} * * * *`, () => {
  runMonitor();
});
