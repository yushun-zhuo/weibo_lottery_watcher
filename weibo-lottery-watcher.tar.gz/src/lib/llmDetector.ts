import axios from 'axios';

interface LlmLotteryResult {
  isLottery: boolean;
  confidence: number;
  prizes: string[];
  deadline: string | null;
  conditions: string[];
}

const LLM_API_KEY = process.env.OPENAI_API_KEY || '';
const LLM_API_BASE = process.env.OPENAI_API_BASE || 'https://api.openai.com/v1';

const PROMPT = `你是一个专业的微博抽奖识别助手。请分析以下微博内容，判断是否为抽奖活动，并提取关键信息。

请返回严格的JSON格式，不要包含任何额外文字或解释。

JSON格式要求：
{
  "isLottery": true/false,
  "confidence": 0-1之间的小数,
  "prizes": ["奖品名称1", "奖品名称2"],
  "deadline": "截止日期字符串或null",
  "conditions": ["条件1", "条件2"]
}

判断标准：
- isLottery: 只有明确表示要抽取、赠送奖品给粉丝的活动才为true
- confidence: 0表示完全不是抽奖，1表示非常确定是抽奖
- prizes: 提取奖品名称，如"iPhone 15"、"红包"、"周边"等
- deadline: 提取截止时间，如"7月21日"、"3天后"等，没有则为null
- conditions: 提取参与条件，如"转发"、"关注"、"评论"、"点赞"等

示例1（抽奖）：
输入：转发抽奖！关注我并转发这条微博，7月20日抽1位粉丝送iPhone 15！
输出：{"isLottery":true,"confidence":0.95,"prizes":["iPhone 15"],"deadline":"7月20日","conditions":["关注","转发"]}

示例2（抽奖）：
输入：转发微博，7月21日抽粉丝送出1部 REDMI Note 17 Pro ~
输出：{"isLottery":true,"confidence":0.9,"prizes":["REDMI Note 17 Pro"],"deadline":"7月21日","conditions":["转发"]}

示例3（非抽奖）：
输入：今天天气真好，大家出门注意防晒哦
输出：{"isLottery":false,"confidence":0.0,"prizes":[],"deadline":null,"conditions":[]}

示例4（抽奖）：
输入：福利来啦！关注+转发+点赞，抽3位送现金红包100元，明天开奖！
输出：{"isLottery":true,"confidence":0.98,"prizes":["现金红包100元"],"deadline":"明天","conditions":["关注","转发","点赞"]}

示例5（非抽奖）：
输入：感谢大家的支持，上一期抽奖已经结束了，获奖名单已公布
输出：{"isLottery":false,"confidence":0.0,"prizes":[],"deadline":null,"conditions":[]}

现在请分析以下微博内容：
`;

export const detectLotteryWithLlm = async (content: string): Promise<LlmLotteryResult> => {
  if (!LLM_API_KEY) {
    console.warn('LLM API key not configured, falling back to rule-based detection');
    return {
      isLottery: false,
      confidence: 0,
      prizes: [],
      deadline: null,
      conditions: [],
    };
  }

  try {
    const response = await axios.post(
      `${LLM_API_BASE}/chat/completions`,
      {
        model: 'gpt-3.5-turbo',
        messages: [
          {
            role: 'user',
            content: PROMPT + content,
          },
        ],
        temperature: 0.1,
        max_tokens: 200,
      },
      {
        headers: {
          'Authorization': `Bearer ${LLM_API_KEY}`,
          'Content-Type': 'application/json',
        },
        timeout: 30000,
      }
    );

    const resultText = response.data.choices[0].message.content.trim();
    
    try {
      const jsonStart = resultText.indexOf('{');
      const jsonEnd = resultText.lastIndexOf('}') + 1;
      const jsonStr = resultText.substring(jsonStart, jsonEnd);
      const result = JSON.parse(jsonStr);
      
      return {
        isLottery: result.isLottery || false,
        confidence: result.confidence || 0,
        prizes: Array.isArray(result.prizes) ? result.prizes : [],
        deadline: result.deadline || null,
        conditions: Array.isArray(result.conditions) ? result.conditions : [],
      };
    } catch {
      console.error('Failed to parse LLM response:', resultText);
      return {
        isLottery: false,
        confidence: 0,
        prizes: [],
        deadline: null,
        conditions: [],
      };
    }
  } catch (error: any) {
    console.error('LLM API error:', error.message);
    return {
      isLottery: false,
      confidence: 0,
      prizes: [],
      deadline: null,
      conditions: [],
    };
  }
};
