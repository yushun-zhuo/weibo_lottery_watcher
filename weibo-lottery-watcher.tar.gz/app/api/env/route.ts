import { NextResponse } from 'next/server';

export async function GET() {
  return NextResponse.json({
    weiboCookie: process.env.WEIBO_COOKIE ? 'SET' : 'NOT SET',
    feishuWebhook: process.env.FEISHU_WEBHOOK_URL ? 'SET' : 'NOT SET',
    cookieLength: process.env.WEIBO_COOKIE?.length || 0,
  });
}
