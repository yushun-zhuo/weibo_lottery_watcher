module.exports = {
  apps: [
    {
      name: 'weibo-lottery-watcher',
      script: 'npm',
      args: 'run start',
      cwd: '/root/weibo-lottery-watcher',
      env: {
        NODE_ENV: 'production',
        PORT: 3000,
      },
      instances: 1,
      autorestart: true,
      watch: false,
      max_memory_restart: '1G',
      log_date_format: 'YYYY-MM-DD HH:mm:ss',
      error_file: './logs/error.log',
      out_file: './logs/out.log',
      merge_logs: true,
    },
  ],
};